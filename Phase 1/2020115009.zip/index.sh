#!/bin/bash
python3 Indexer.py $1 $2
